//package com.prdTest;
//
//import com.microsoft.azure.functions.ExecutionContext;
//import com.microsoft.azure.functions.HttpMethod;
//import com.microsoft.azure.functions.HttpRequestMessage;
//import com.microsoft.azure.functions.HttpResponseMessage;
//import com.microsoft.azure.functions.HttpStatus;
//import com.microsoft.azure.functions.annotation.AuthorizationLevel;
//import com.microsoft.azure.functions.annotation.FunctionName;
//import com.microsoft.azure.functions.annotation.HttpTrigger;
//
//import org.bouncycastle.cert.jcajce.JcaCertStore;
//import org.bouncycastle.cms.CMSAlgorithm;
//import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoGeneratorBuilder;
//import org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder;
//import org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator;
//import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
//import org.bouncycastle.mail.smime.SMIMESignedGenerator;
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMultipart;
//import java.io.ByteArrayOutputStream;
//import java.io.FileInputStream;
//import java.security.KeyStore;
//import java.security.PrivateKey;
//import java.security.cert.Certificate;
//import java.security.cert.CertificateFactory;
//import java.security.cert.X509Certificate;
//import java.util.Collections;
//import java.util.List;
//import java.util.Optional;
//
///**
// * Azure Functions with HTTP Trigger to encrypt and sign messages.
// */
//public class HttpTriggerFunction {
//
//    @FunctionName("HttpExample")
//    public HttpResponseMessage run(
//            @HttpTrigger(
//                    name = "req",
//                    methods = {HttpMethod.GET, HttpMethod.POST},
//                    authLevel = AuthorizationLevel.ANONYMOUS)
//            HttpRequestMessage<Optional<String>> request,
//            final ExecutionContext context) {
//        context.getLogger().info("Java HTTP trigger processed a request.");
//
//        // Parse query parameter or body
//        final String query = request.getQueryParameters().get("message");
//        final String message = request.getBody().orElse(query);
//
//        if (message == null) {
//            return request.createResponseBuilder(HttpStatus.BAD_REQUEST)
//                    .body("Please pass a message on the query string or in the request body").build();
//        }
//
//        try {
//            // Encrypt and sign the message
//            ByteArrayOutputStream encryptedMessage = encryptAndSignMessage(message);
//
//            // Return the encrypted and signed message as response
//            return request.createResponseBuilder(HttpStatus.OK)
//                    .body("Encrypted and signed message: " + new String(encryptedMessage.toByteArray())).build();
//
//        } catch (Exception e) {
//            context.getLogger().severe("Error occurred: " + e.getMessage());
//            return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("An error occurred during encryption and signing.").build();
//        }
//    }
//
//    public ByteArrayOutputStream encryptAndSignMessage(String messageContent) throws Exception {
//        // Step 1: Create the MimeBodyPart for the message content
//        MimeBodyPart aMsgBodyPart = new MimeBodyPart();
//        aMsgBodyPart.setText(messageContent);
//
//        // Step 2: Load the sender's private key and certificate from .pfx file
//        String senderPfxPath = "path_to_sender_pfx.pfx";  // Path to your .pfx file
//        String senderPassword = "your_pfx_password";  // Password for the .pfx file
//
//        KeyStore keystore = KeyStore.getInstance("PKCS12", "BC");
//        try (FileInputStream pfxInputStream = new FileInputStream(senderPfxPath)) {
//            keystore.load(pfxInputStream, senderPassword.toCharArray());
//        }
//        String alias = keystore.aliases().nextElement();
//        PrivateKey senderPrivateKey = (PrivateKey) keystore.getKey(alias, senderPassword.toCharArray());
//        X509Certificate senderCert = (X509Certificate) keystore.getCertificate(alias);
//
//        // Step 3: Load recipient's public certificate from .cer file
//        String recipientCerPath = "path_to_recipient_cert.cer";  // Path to recipient's .cer file
//
//        X509Certificate recipientCert;
//        try (FileInputStream fis = new FileInputStream(recipientCerPath)) {
//            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
//            recipientCert = (X509Certificate) certFactory.generateCertificate(fis);
//        }
//
//        // Step 4: Sign the message using the sender's private key
//        SMIMESignedGenerator signer = new SMIMESignedGenerator();
//        signer.addSignerInfoGenerator(new JcaSimpleSignerInfoGeneratorBuilder()
//                .setProvider("BC")
//                .build("SHA1withRSA", senderPrivateKey, senderCert));
//
//        List<Certificate> certList = Collections.singletonList(senderCert);
//        JcaCertStore certs = new JcaCertStore(certList);
//        signer.addCertificates(certs);
//
//        MimeMultipart signedMultipart = signer.generate(aMsgBodyPart);
//
//        // Step 5: Encrypt the signed message using recipient's public key
//        SMIMEEnvelopedGenerator encrypter = new SMIMEEnvelopedGenerator();
//        encrypter.addRecipientInfoGenerator(
//                new JceKeyTransRecipientInfoGenerator(recipientCert).setProvider("BC")
//        );
//
//        MimeBodyPart encryptedPart = encrypter.generate(signedMultipart,
//                new JceCMSContentEncryptorBuilder(CMSAlgorithm.RC2_CBC).setProvider("BC").build());
//
//        // Step 6: Output the encrypted and signed message
//        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
//        encryptedPart.writeTo(outputStream);
//
//        return outputStream;
//    }
//}



/// new working one

//package com.prdTest;

//import com.microsoft.azure.functions.ExecutionContext;
//import com.microsoft.azure.functions.HttpMethod;
//import com.microsoft.azure.functions.HttpRequestMessage;
//import com.microsoft.azure.functions.HttpResponseMessage;
//import com.microsoft.azure.functions.HttpStatus;
//import com.microsoft.azure.functions.annotation.AuthorizationLevel;
//import com.microsoft.azure.functions.annotation.FunctionName;
//import com.microsoft.azure.functions.annotation.HttpTrigger;
//
//import org.bouncycastle.asn1.smime.SMIMECapability;
//import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
//import org.bouncycastle.cert.jcajce.JcaCertStore;
//import org.bouncycastle.cms.CMSAlgorithm;
//import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoGeneratorBuilder;
//import org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder;
//import org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator;
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
//import org.bouncycastle.mail.smime.SMIMESignedGenerator;
//import org.bouncycastle.operator.OutputEncryptor;
//
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMultipart;
//import java.io.FileInputStream;
//import java.security.KeyStore;
//import java.security.PrivateKey;
//import java.security.Security;
//import java.security.cert.Certificate;
//import java.security.cert.CertificateFactory;
//import java.security.cert.X509Certificate;
//import java.util.ArrayList;
//import java.util.Enumeration;
//import java.util.List;
//import java.util.Optional;
//
///**
// * Azure Functions with HTTP Trigger.
// */
//public class HttpTriggerFunction {
//    private static final String PROFILE_PATH = "C:\\Users\\vikash.nayak\\Downloads\\SMIMETool\\SMIMETool\\CER\\BLPFX.pfx";
//    private static final String PROFILE_PASSWORD = "Citibank#12";
//    private static final String RECIPIENT_CERT_PATH = "C:/Users/vikash.nayak/Downloads/SMIMETool2/CER/Citi.cer";
//    
//    @FunctionName("HttpExample")
//    public HttpResponseMessage run(
//            @HttpTrigger(
//                    name = "req",
//                    methods = {HttpMethod.GET, HttpMethod.POST},
//                    authLevel = AuthorizationLevel.ANONYMOUS)
//                    HttpRequestMessage<Optional<String>> request,
//            final ExecutionContext context) {
//
//        context.getLogger().info("Java HTTP trigger processed a request.");
//
//        // Retrieve message to be signed and encrypted
//        final String message = request.getQueryParameters().get("message");
//        if (message == null) {
//            return request.createResponseBuilder(HttpStatus.BAD_REQUEST)
//                    .body("Please pass a message on the query string.")
//                    .build();
//        }
//
//        try {
//            // 1. Sign the message
//            MimeBodyPart signedMessage = signMessage(message, context);
//
//            // 2. Encrypt the signed message
//            MimeBodyPart encryptedMessage = encryptMessage(signedMessage, context);
//
//            // Return a success response (just for demo purposes, you may want to send encryptedMessage somewhere)
//            return request.createResponseBuilder(HttpStatus.OK)
//                    .body("Message signed and encrypted successfully.")
//                    .build();
//
//        } catch (Exception e) {
//            context.getLogger().severe("Error during signing/encryption: " + e.getMessage());
//            return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Error occurred: " + e.getMessage())
//                    .build();
//        }
//    }
//
//    private MimeBodyPart signMessage(String messageContent, ExecutionContext context) throws Exception {
//        // Initialize Bouncy Castle provider
//        Security.addProvider(new BouncyCastleProvider());
//
//        // Load the keystore (containing the sender's private key and certificate)
//        KeyStore keystore = KeyStore.getInstance("PKCS12","BC");
//        keystore.load(new FileInputStream(PROFILE_PATH), PROFILE_PASSWORD.toCharArray());
//
//        // Get the private key and certificate from the keystore
//        String keyAlias = null;
//        for (Enumeration<String> e = keystore.aliases(); e.hasMoreElements() && keyAlias == null;) {
//            String alias = e.nextElement();
//            if (keystore.isKeyEntry(alias)) {
//                keyAlias = alias;
//            }
//        }
//
//        Certificate[] chain = keystore.getCertificateChain(keyAlias);
//        PrivateKey privateKey = (PrivateKey) keystore.getKey(keyAlias, PROFILE_PASSWORD.toCharArray());
//
//        // Create the SMIMESignedGenerator for signing
//        SMIMESignedGenerator signer = new SMIMESignedGenerator();
//
//        // Set signing capabilities
//        SMIMECapabilityVector capabilities = new SMIMECapabilityVector();
//        capabilities.addCapability(SMIMECapability.dES_EDE3_CBC);
//        capabilities.addCapability(SMIMECapability.rC2_CBC, 128);
//        capabilities.addCapability(SMIMECapability.dES_CBC);
//
//        // Add the signer information
//        signer.addSignerInfoGenerator(new JcaSimpleSignerInfoGeneratorBuilder()
//                .setProvider("BC")
//                .build("SHA1withRSA", privateKey, (X509Certificate) chain[0]));
//
//        // Create certificate store and add the certificate
//        List<X509Certificate> certList = new ArrayList<>();
//        certList.add((X509Certificate) chain[0]);
//        signer.addCertificates(new JcaCertStore(certList));
//
//        // Create the message to be signed
//        MimeBodyPart messagePart = new MimeBodyPart();
//        messagePart.setText(messageContent);
//
//        // Sign the message and create a MimeMultipart
//        MimeMultipart signedMultipart = signer.generate(messagePart);
//
//        // Create a MimeBodyPart to hold the signed MimeMultipart
//        MimeBodyPart signedBodyPart = new MimeBodyPart();
//        signedBodyPart.setContent(signedMultipart);
//
//        context.getLogger().info("Message signed successfully.");
//        return signedBodyPart;
//    }
//
//    private MimeBodyPart encryptMessage(MimeBodyPart signedBodyPart, ExecutionContext context) throws Exception {
//        // Load the recipient's public certificate (.cer file)
//        X509Certificate recipientCert = loadRecipientCertificate();
//
//        // Initialize the encrypter
//        SMIMEEnvelopedGenerator encrypter = new SMIMEEnvelopedGenerator();
//        encrypter.addRecipientInfoGenerator(new JceKeyTransRecipientInfoGenerator(recipientCert).setProvider("BC"));
//
//        // Encrypt the signed message
//        OutputEncryptor encryptor = new JceCMSContentEncryptorBuilder(CMSAlgorithm.RC2_CBC).setProvider("BC").build();
//        MimeBodyPart encryptedPart = encrypter.generate(signedBodyPart, encryptor);
//
//        context.getLogger().info("Message encrypted successfully.");
//        return encryptedPart;
//    }
//
//    private X509Certificate loadRecipientCertificate() throws Exception {
//        // Load recipient's certificate from the .cer file
//        FileInputStream fis = new FileInputStream(RECIPIENT_CERT_PATH);
//        Certificate cert = CertificateFactory.getInstance("X.509").generateCertificate(fis);
//        return (X509Certificate) cert;
//    }
//}





//// Proper Working Code ////////




//package com.prdTest;
//
//import com.microsoft.azure.functions.ExecutionContext;
//import com.microsoft.azure.functions.HttpMethod;
//import com.microsoft.azure.functions.HttpRequestMessage;
//import com.microsoft.azure.functions.HttpResponseMessage;
//import com.microsoft.azure.functions.HttpStatus;
//import com.microsoft.azure.functions.annotation.AuthorizationLevel;
//import com.microsoft.azure.functions.annotation.FunctionName;
//import com.microsoft.azure.functions.annotation.HttpTrigger;
//
//
//import org.bouncycastle.asn1.smime.SMIMECapability;
//import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
//import org.bouncycastle.cert.jcajce.JcaCertStore;
//import org.bouncycastle.cms.CMSAlgorithm;
//import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoGeneratorBuilder;
//import org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder;
//import org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator;
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
//import org.bouncycastle.mail.smime.SMIMESignedGenerator;
//import org.bouncycastle.operator.OutputEncryptor;
//
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMultipart;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.security.KeyStore;
//import java.security.PrivateKey;
//import java.security.Security;
//import java.security.cert.Certificate;
//import java.security.cert.CertificateFactory;
//import java.security.cert.X509Certificate;
//import java.util.ArrayList;
//import java.util.Enumeration;
//import java.util.List;
//import java.util.Optional;
//
///**
// * Azure Functions with HTTP Trigger.
// */
//public class HttpTriggerFunction {
//    private static final String PROFILE_PATH = "C:\\Users\\vikash.nayak\\Downloads\\SMIMETool\\SMIMETool\\CER\\BLPFX.pfx";
//    private static final String PROFILE_PASSWORD = "Citibank#12";
//    private static final String RECIPIENT_CERT_PATH = "C:/Users/vikash.nayak/Downloads/SMIMETool2/CER/Citi.cer";
//   
//    @FunctionName("HttpExample")
//    public HttpResponseMessage run(
//            @HttpTrigger(
//                    name = "req",
//                    methods = {HttpMethod.GET, HttpMethod.POST},
//                    authLevel = AuthorizationLevel.ANONYMOUS)
//                    HttpRequestMessage<Optional<String>> request,
//            final ExecutionContext context) {
//
//        context.getLogger().info("Java HTTP trigger processed a request.");
//
//        // Retrieve message to be signed and encrypted
//        final String message = request.getQueryParameters().get("message");
//        if (message == null) {
//            return request.createResponseBuilder(HttpStatus.BAD_REQUEST)
//                    .body("Please pass a message on the query string.")
//                    .build();
//        }
//
//        try {
//        	
//            // 1. Sign the message
//            MimeBodyPart signedMessage = signMessage(message, context);
//
//            // 2. Encrypt the signed message
//            MimeBodyPart encryptedMessage = encryptMessage(signedMessage, context);
//
//            // Return a success response (just for demo purposes, you may want to send encryptedMessage somewhere)
//            return request.createResponseBuilder(HttpStatus.OK)
//                    .body("Message signed and encrypted successfully.")
//                    .build();
//
//        } catch (Exception e) {
//            context.getLogger().severe("Error during signing/encryption: " + e.getMessage());
//            return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Error occurred: " + e.getMessage())
//                    .build();
//        }
//    }
//
//    private MimeBodyPart signMessage(String messageContent, ExecutionContext context) throws Exception {
//        // Initialize Bouncy Castle provider
//        Security.addProvider(new BouncyCastleProvider());
//
//        // Load the keystore (containing the sender's private key and certificate)
//        KeyStore keystore = KeyStore.getInstance("PKCS12","BC");
//        keystore.load(new FileInputStream(PROFILE_PATH), PROFILE_PASSWORD.toCharArray());
//
//        // Get the private key and certificate from the keystore
//        String keyAlias = null;
//        for (Enumeration<String> e = keystore.aliases(); e.hasMoreElements() && keyAlias == null;) {
//            String alias = e.nextElement();
//            if (keystore.isKeyEntry(alias)) {
//                keyAlias = alias;
//            }
//        }
//
//        Certificate[] chain = keystore.getCertificateChain(keyAlias);
//        PrivateKey privateKey = (PrivateKey) keystore.getKey(keyAlias, PROFILE_PASSWORD.toCharArray());
//
//        // Create the SMIMESignedGenerator for signing
//        SMIMESignedGenerator signer = new SMIMESignedGenerator();
//
//        // Set signing capabilities
//        SMIMECapabilityVector capabilities = new SMIMECapabilityVector();
//        capabilities.addCapability(SMIMECapability.dES_EDE3_CBC);
//        capabilities.addCapability(SMIMECapability.rC2_CBC, 128);
//        capabilities.addCapability(SMIMECapability.dES_CBC);
//
//        // Add the signer information
//        signer.addSignerInfoGenerator(new JcaSimpleSignerInfoGeneratorBuilder()
//                .setProvider("BC")
//                .build("SHA1withRSA", privateKey, (X509Certificate) chain[0]));
//
//        // Create certificate store and add the certificate
//        List<X509Certificate> certList = new ArrayList<>();
//        certList.add((X509Certificate) chain[0]);
//        signer.addCertificates(new JcaCertStore(certList));
//
//        // Create the message to be signed
//        MimeBodyPart messagePart = new MimeBodyPart();
//        messagePart.setText(messageContent);
//
//        // Sign the message and create a MimeMultipart
//        MimeMultipart signedMultipart = signer.generate(messagePart);
//
//        // Create a MimeBodyPart to hold the signed MimeMultipart
//        MimeBodyPart signedBodyPart = new MimeBodyPart();
//        signedBodyPart.setContent(signedMultipart);
//
//        context.getLogger().info("Message signed successfully.");
//        return signedBodyPart;
//    }
//
//    private MimeBodyPart encryptMessage(MimeBodyPart signedBodyPart, ExecutionContext context) throws Exception {
//        // Load the recipient's public certificate (.cer file)
//        X509Certificate recipientCert = loadRecipientCertificate();
//
//        // Initialize the encrypter
//        SMIMEEnvelopedGenerator encrypter = new SMIMEEnvelopedGenerator();
//        encrypter.addRecipientInfoGenerator(new JceKeyTransRecipientInfoGenerator(recipientCert).setProvider("BC"));
//
//        // Encrypt the signed message
//        OutputEncryptor encryptor = new JceCMSContentEncryptorBuilder(CMSAlgorithm.RC2_CBC).setProvider("BC").build();
//        MimeBodyPart encryptedPart = encrypter.generate(signedBodyPart, encryptor);
//
//        // Save the encrypted message to a .txt.p7m file
//        saveEncryptedMessageToFile(encryptedPart, "encrypted_message.txt.p7m", context);
//
//        context.getLogger().info("Message encrypted and saved successfully.");
//        return encryptedPart;
//    }
//
//    private void saveEncryptedMessageToFile(MimeBodyPart encryptedPart, String fileName, ExecutionContext context) throws Exception {
//        // Define the path where the file will be saved
//        String filePath = "C:\\Users\\vikash.nayak\\Downloads\\" + fileName;
//
//        // Create an output stream to write the encrypted message to a file
//        try (FileOutputStream fos = new FileOutputStream(filePath)) {
//            // Write the content of the encrypted MimeBodyPart to the file
//            encryptedPart.writeTo(fos);
//        } catch (Exception e) {
//            context.getLogger().severe("Error saving encrypted message to file: " + e.getMessage());
//            throw e;
//        }
//    }
//
//    private X509Certificate loadRecipientCertificate() throws Exception {
//        // Load recipient's certificate from the .cer file
//        FileInputStream fis = new FileInputStream(RECIPIENT_CERT_PATH);
//        Certificate cert = CertificateFactory.getInstance("X.509").generateCertificate(fis);
//        return (X509Certificate) cert;
//    }
//}


//////////////////////////////////////////////////////////////////////////////////////////////


//package com.prdTest;
//
//import com.azure.storage.blob.*;
//import com.azure.storage.blob.models.*;
//import com.microsoft.azure.functions.*;
//import com.microsoft.azure.functions.annotation.*;
//
//import org.bouncycastle.asn1.smime.SMIMECapability;
//import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
//import org.bouncycastle.cert.jcajce.JcaCertStore;
//import org.bouncycastle.cms.CMSAlgorithm;
//import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoGeneratorBuilder;
//import org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder;
//import org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator;
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
//import org.bouncycastle.mail.smime.SMIMESignedGenerator;
//import org.bouncycastle.operator.OutputEncryptor;
//
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMultipart;
//import java.io.*;
//import java.security.*;
//import java.security.cert.*;
//import java.util.*;
//
//public class HttpTriggerFunction {
//
//    private static final String AZURE_STORAGE_CONNECTION = "DefaultEndpointsProtocol=https;AccountName=azchnn3ssdevlogicapp01;AccountKey=L55niZUJ2G60rYaBV0kQaJdkia0NyqepbAaQa8EgFKHhrQSKhMJtZf0nVCGDUwscCqR3Gr+jfX+x+AStzLLkEg==;EndpointSuffix=core.chinacloudapi.cn";
//    private static final String AZURE_CONTAINER_NAME = "development-citibankintegration-ap";
//    private static final String AZURE_INPUT_DIRECTORY = "IN";
//    private static final String AZURE_OUTPUT_DIRECTORY = "OUT";
//    private static final String CERTIFICATE_DIRECTORY = "certificate";
//    private static final String PROFILE_NAME = "BLPFX.pfx";
//    private static final String CERTIFICATE_NAME = "Citi.cer";
//
//    @FunctionName("HttpExample")
//    public HttpResponseMessage run(
//            @HttpTrigger(name = "req", methods = {HttpMethod.GET}, authLevel = AuthorizationLevel.ANONYMOUS)
//                    HttpRequestMessage<Optional<String>> request,
//            final ExecutionContext context) {
//
//        context.getLogger().info("Java HTTP trigger processed a GET request.");
//
//        try {
//            // Read profile and certificate from Azure Blob Storage
//            InputStream profileInputStream = downloadBlob(PROFILE_NAME, CERTIFICATE_DIRECTORY, context);
//            InputStream certInputStream = downloadBlob(CERTIFICATE_NAME, CERTIFICATE_DIRECTORY, context);
//
//            // Get all files from the 'IN' directory
//            List<String> fileNames = getFileNamesFromBlobDirectory(AZURE_INPUT_DIRECTORY, context);
//            if (fileNames.isEmpty()) {
//                return request.createResponseBuilder(HttpStatus.NOT_FOUND)
//                        .body("No files found in the 'IN' directory.")
//                        .build();
//            }
//
//            // Process each file
//            for (String fileName : fileNames) {
//                // Read the file content from the 'IN' directory in Blob Storage
//                InputStream fileInputStream = downloadBlob(fileName, AZURE_INPUT_DIRECTORY, context);
//                String message = new String(fileInputStream.readAllBytes(), "UTF-8");
//
//                // 1. Sign the message (from file content)
//                MimeBodyPart signedMessage = signMessage(message, profileInputStream, context);
//
//                // 2. Encrypt the signed message
//                MimeBodyPart encryptedMessage = encryptMessage(signedMessage, certInputStream, context);
//
//                // Save the encrypted message to the 'OUT' directory in Azure Blob Storage
//                uploadBlob(encryptedMessage, "encrypted_" + fileName + ".p7m", AZURE_OUTPUT_DIRECTORY, context);
//            }
//
//            return request.createResponseBuilder(HttpStatus.OK)
//                    .body("All files signed and encrypted successfully. Output saved in the 'OUT' directory.")
//                    .build();
//
//        } catch (Exception e) {
//            context.getLogger().severe("Error during signing/encryption: " + e.getMessage());
//            return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Error occurred: " + e.getMessage())
//                    .build();
//        }
//    }
//
//    private MimeBodyPart signMessage(String messageContent, InputStream profileInputStream, ExecutionContext context) throws Exception {
//        Security.addProvider(new BouncyCastleProvider());
//
//        KeyStore keystore = KeyStore.getInstance("PKCS12", "BC");
//        keystore.load(profileInputStream, "PROFILE_PASSWORD".toCharArray());
//
//        String keyAlias = null;
//        for (Enumeration<String> e = keystore.aliases(); e.hasMoreElements() && keyAlias == null; ) {
//            String alias = e.nextElement();
//            if (keystore.isKeyEntry(alias)) {
//                keyAlias = alias;
//            }
//        }
//
//        Certificate[] chain = keystore.getCertificateChain(keyAlias);
//        PrivateKey privateKey = (PrivateKey) keystore.getKey(keyAlias, "PROFILE_PASSWORD".toCharArray());
//
//        SMIMESignedGenerator signer = new SMIMESignedGenerator();
//
//        SMIMECapabilityVector capabilities = new SMIMECapabilityVector();
//        capabilities.addCapability(SMIMECapability.dES_EDE3_CBC);
//        capabilities.addCapability(SMIMECapability.rC2_CBC, 128);
//        capabilities.addCapability(SMIMECapability.dES_CBC);
//
//        signer.addSignerInfoGenerator(new JcaSimpleSignerInfoGeneratorBuilder()
//                .setProvider("BC")
//                .build("SHA1withRSA", privateKey, (X509Certificate) chain[0]));
//
//        List<X509Certificate> certList = new ArrayList<>();
//        certList.add((X509Certificate) chain[0]);
//        signer.addCertificates(new JcaCertStore(certList));
//
//        MimeBodyPart messagePart = new MimeBodyPart();
//        messagePart.setText(messageContent);
//
//        MimeMultipart signedMultipart = signer.generate(messagePart);
//
//        MimeBodyPart signedBodyPart = new MimeBodyPart();
//        signedBodyPart.setContent(signedMultipart);
//
//        context.getLogger().info("Message signed successfully.");
//        return signedBodyPart;
//    }
//
//    private MimeBodyPart encryptMessage(MimeBodyPart signedBodyPart, InputStream certInputStream, ExecutionContext context) throws Exception {
//        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
//        X509Certificate recipientCert = (X509Certificate) certFactory.generateCertificate(certInputStream);
//
//        SMIMEEnvelopedGenerator encrypter = new SMIMEEnvelopedGenerator();
//        encrypter.addRecipientInfoGenerator(new JceKeyTransRecipientInfoGenerator(recipientCert).setProvider("BC"));
//
//        OutputEncryptor encryptor = new JceCMSContentEncryptorBuilder(CMSAlgorithm.RC2_CBC).setProvider("BC").build();
//        MimeBodyPart encryptedPart = encrypter.generate(signedBodyPart, encryptor);
//
//        context.getLogger().info("Message encrypted successfully.");
//        return encryptedPart;
//    }
//
//    private void uploadBlob(MimeBodyPart encryptedPart, String fileName, String directory, ExecutionContext context) throws Exception {
//        BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
//                .connectionString(AZURE_STORAGE_CONNECTION)
//                .buildClient();
//        BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(AZURE_CONNECTION);
//        BlobClient blobClient = containerClient.getBlobClient(directory + "/" + fileName);
//
//        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
//            encryptedPart.writeTo(bos);
//            blobClient.upload(new ByteArrayInputStream(bos.toByteArray()), bos.size(), true);
//        } catch (Exception e) {
//            context.getLogger().severe("Error uploading encrypted message: " + e.getMessage());
//            throw e;
//        }
//    }
//
//    private InputStream downloadBlob(String fileName, String directory, ExecutionContext context) throws Exception {
//        BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
//                .connectionString(AZURE_STORAGE_CONNECTION)
//                .buildClient();
//        BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(AZURE_CONNECTION);
//        BlobClient blobClient = containerClient.getBlobClient(directory + "/" + fileName);
//
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        blobClient.download(bos);
//        return new ByteArrayInputStream(bos.toByteArray());
//    }
//
//    private List<String> getFileNamesFromBlobDirectory(String directory, ExecutionContext context) throws Exception {
//        List<String> fileNames = new ArrayList<>();
//        BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
//                .connectionString(AZURE_STORAGE_CONNECTION)
//                .buildClient();
//        BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(AZURE_CONNECTION);
//
//        for (BlobItem blobItem : containerClient.listBlobsByHierarchy(directory + "/")) {
//            fileNames.add(blobItem.getName());
//            context.getLogger().info("Found blob: " + blobItem.getName());
//        }
//
//        return fileNames;
//    }
//}



//package com.prdTest;
//
////package com.prdTest;
//
//import com.microsoft.azure.functions.*;
//import com.microsoft.azure.storage.*;
//import com.microsoft.azure.storage.blob.*;
//
//import java.util.*;
//
//public class HttpTriggerFunction {
//
//    private static final String SAS_TOKEN = "DefaultEndpointsProtocol=https;AccountName=azchnn3ssdevlogicapp01;AccountKey=L55niZUJ2G60rYaBV0kQaJdkia0NyqepbAaQa8EgFKHhrQSKhMJtZf0nVCGDUwscCqR3Gr+jfX+x+AStzLLkEg==;EndpointSuffix=core.chinacloudapi.cn";
//
//    @FunctionName("HttpExample")
//    public HttpResponseMessage run(
//        @HttpTrigger(name = "req", methods = {HttpMethod.GET}, authLevel = AuthorizationLevel.ANONYMOUS) 
//        HttpRequestMessage<Optional<String>> request,
//        final ExecutionContext context
//    ) {
//        context.getLogger().info("Java HTTP trigger function processed a request.");
//
//        String containerName = "development-citibankintegration-ap";
//        String directoryName = "IN";
//
//        try {
//            if (SAS_TOKEN == null || SAS_TOKEN.isEmpty()) {
//                return request.createResponseBuilder(HttpStatus.BAD_REQUEST)
//                        .body("SAS Token is missing or empty")
//                        .build();
//            }
//
//            // Create a CloudStorageAccount Object
//            CloudStorageAccount storageAccount = CloudStorageAccount.parse(SAS_TOKEN);
//
//            // Create a CloudBlobClient Object
//            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
//
//            // Create a Cloud Blob Container
//            CloudBlobContainer blobContainer = blobClient.getContainerReference(containerName);
//
//            // Create a Cloud blob Directory
//            CloudBlobDirectory blobDirectory = blobContainer.getDirectoryReference(directoryName);
//
//            // List all blobs in the directory
//            StringBuilder responseContent = new StringBuilder();
//            for (ListBlobItem blobItem : blobDirectory.listBlobs()) {
//                if (blobItem instanceof CloudBlockBlob) {
//                    CloudBlockBlob blockBlob = (CloudBlockBlob) blobItem;
//                    responseContent.append("Blob: ").append(blockBlob.getName()).append("\n");
//                    
//                    // Optionally, download the blob text
//                    try {
//                        String blobContent = blockBlob.downloadText();
//                        responseContent.append("Content: ").append(blobContent).append("\n");
//                    } catch (Exception e) {
//                        context.getLogger().severe("Error downloading blob content: " + e.getMessage());
//                        responseContent.append("Error downloading blob content: ").append(e.getMessage()).append("\n");
//                    }
//                }
//            }
//
//            return request.createResponseBuilder(HttpStatus.OK)
//                    .body(responseContent.toString())
//                    .build();
//        } catch (Exception e) {
//            context.getLogger().severe("Error: " + e.getMessage());
//            return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Error: " + e.getMessage())
//                    .build();
//        }
//    }
//}



//package com.prdTest;
//
//import com.microsoft.azure.storage.*;
//import com.microsoft.azure.storage.blob.*;
//import com.microsoft.azure.storage.blob.CloudBlobContainer;
//import com.microsoft.azure.storage.blob.CloudBlobClient;
//import com.microsoft.azure.storage.blob.CloudBlockBlob;
//import com.microsoft.azure.storage.blob.ListBlobItem;
//import com.microsoft.azure.storage.blob.SharedAccessBlobPolicy;
//
//import com.microsoft.azure.functions.*;
//import com.microsoft.azure.functions.annotation.*;
//
//import org.bouncycastle.asn1.smime.SMIMECapability;
//import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
//import org.bouncycastle.cert.jcajce.JcaCertStore;
//import org.bouncycastle.cms.CMSAlgorithm;
//import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoGeneratorBuilder;
//import org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder;
//import org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator;
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
//import org.bouncycastle.mail.smime.SMIMESignedGenerator;
//import org.bouncycastle.operator.OutputEncryptor;
//
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMultipart;
//import java.io.*;
//import java.security.*;
//import java.security.cert.*;
//import java.util.*;
//
//public class HttpTriggerFunction {
//
//    private static final String AZURE_STORAGE_CONNECTION = "DefaultEndpointsProtocol=https;AccountName=azchnn3ssdevlogicapp01;AccountKey=L55niZUJ2G60rYaBV0kQaJdkia0NyqepbAaQa8EgFKHhrQSKhMJtZf0nVCGDUwscCqR3Gr+jfX+x+AStzLLkEg==;EndpointSuffix=core.chinacloudapi.cn";
//    private static final String AZURE_CONTAINER_NAME = "development-citibankintegration-ap";
//    private static final String AZURE_INPUT_DIRECTORY = "IN";
//    private static final String AZURE_OUTPUT_DIRECTORY = "OUT";
//    private static final String CERTIFICATE_DIRECTORY = "certificate";
//    private static final String PROFILE_NAME = "BLPFX.pfx";
//    private static final String CERTIFICATE_NAME = "Citi.cer";
//    private static final String PROFILE_PASSWORD = "Citibank#12"; // Ensure this is securely managed
//
//    @FunctionName("HttpExample")
//    public HttpResponseMessage run(
//            @HttpTrigger(name = "req", methods = {HttpMethod.GET}, authLevel = AuthorizationLevel.ANONYMOUS)
//                    HttpRequestMessage<Optional<String>> request,
//            final ExecutionContext context) {
//
//        context.getLogger().info("Java HTTP trigger processed a GET request.");
//
//        try {
//            // Read profile and certificate from Azure Blob Storage
//            InputStream profileInputStream = downloadBlob(PROFILE_NAME, CERTIFICATE_DIRECTORY, context);
//            InputStream certInputStream = downloadBlob(CERTIFICATE_NAME, CERTIFICATE_DIRECTORY, context);
//
//            // Get all files from the 'IN' directory
//            List<String> fileNames = getFileNamesFromBlobDirectory(AZURE_INPUT_DIRECTORY, context);
//            if (fileNames.isEmpty()) {
//                return request.createResponseBuilder(HttpStatus.NOT_FOUND)
//                        .body("No files found in the 'IN' directory.")
//                        .build();
//            }
//
//            // Process each file
//            for (String fileName : fileNames) {
//                // Read the file content from the 'IN' directory in Blob Storage
//                InputStream fileInputStream = downloadBlob(fileName, AZURE_INPUT_DIRECTORY, context);
//                String message = new String(fileInputStream.readAllBytes(), "UTF-8");
//
//                // 1. Sign the message (from file content)
//                MimeBodyPart signedMessage = signMessage(message, profileInputStream, context);
//
//                // 2. Encrypt the signed message
//                MimeBodyPart encryptedMessage = encryptMessage(signedMessage, certInputStream, context);
//
//                // Save the encrypted message to the 'OUT' directory in Azure Blob Storage
//                uploadBlob(encryptedMessage, "encrypted_" + fileName + ".p7m", AZURE_OUTPUT_DIRECTORY, context);
//            }
//
//            return request.createResponseBuilder(HttpStatus.OK)
//                    .body("All files signed and encrypted successfully. Output saved in the 'OUT' directory.")
//                    .build();
//
//        } catch (Exception e) {
//            context.getLogger().severe("Error during signing/encryption: " + e.getMessage());
//            return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Error occurred: " + e.getMessage())
//                    .build();
//        }
//    }
//
//    private MimeBodyPart signMessage(String messageContent, InputStream profileInputStream, ExecutionContext context) throws Exception {
//        Security.addProvider(new BouncyCastleProvider());
//
//        KeyStore keystore = KeyStore.getInstance("PKCS12", "BC");
//        keystore.load(profileInputStream, PROFILE_PASSWORD.toCharArray());
//
//        String keyAlias = null;
//        for (Enumeration<String> e = keystore.aliases(); e.hasMoreElements() && keyAlias == null; ) {
//            String alias = e.nextElement();
//            if (keystore.isKeyEntry(alias)) {
//                keyAlias = alias;
//            }
//        }
//
//        Certificate[] chain = keystore.getCertificateChain(keyAlias);
//        PrivateKey privateKey = (PrivateKey) keystore.getKey(keyAlias, PROFILE_PASSWORD.toCharArray());
//
//        SMIMESignedGenerator signer = new SMIMESignedGenerator();
//
//        SMIMECapabilityVector capabilities = new SMIMECapabilityVector();
//        capabilities.addCapability(SMIMECapability.dES_EDE3_CBC);
//        capabilities.addCapability(SMIMECapability.rC2_CBC, 128);
//        capabilities.addCapability(SMIMECapability.dES_CBC);
//
//        signer.addSignerInfoGenerator(new JcaSimpleSignerInfoGeneratorBuilder()
//                .setProvider("BC")
//                .build("SHA1withRSA", privateKey, (X509Certificate) chain[0]));
//
//        List<X509Certificate> certList = new ArrayList<>();
//        certList.add((X509Certificate) chain[0]);
//        signer.addCertificates(new JcaCertStore(certList));
//
//        MimeBodyPart messagePart = new MimeBodyPart();
//        messagePart.setText(messageContent);
//
//        MimeMultipart signedMultipart = signer.generate(messagePart);
//
//        MimeBodyPart signedBodyPart = new MimeBodyPart();
//        signedBodyPart.setContent(signedMultipart);
//
//        context.getLogger().info("Message signed successfully.");
//        return signedBodyPart;
//    }
//
//    private MimeBodyPart encryptMessage(MimeBodyPart signedBodyPart, InputStream certInputStream, ExecutionContext context) throws Exception {
//        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
//        X509Certificate recipientCert = (X509Certificate) certFactory.generateCertificate(certInputStream);
//
//        SMIMEEnvelopedGenerator encrypter = new SMIMEEnvelopedGenerator();
//        encrypter.addRecipientInfoGenerator(new JceKeyTransRecipientInfoGenerator(recipientCert).setProvider("BC"));
//
//        OutputEncryptor encryptor = new JceCMSContentEncryptorBuilder(CMSAlgorithm.RC2_CBC).setProvider("BC").build();
//        MimeBodyPart encryptedPart = encrypter.generate(signedBodyPart, encryptor);
//
//        context.getLogger().info("Message encrypted successfully.");
//        return encryptedPart;
//    }
//
//    private void uploadBlob(MimeBodyPart encryptedPart, String fileName, String directory, ExecutionContext context) throws Exception {
//        CloudStorageAccount storageAccount = CloudStorageAccount.parse(AZURE_STORAGE_CONNECTION);
//        CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
//        CloudBlobContainer container = blobClient.getContainerReference(AZURE_CONTAINER_NAME);
//        CloudBlockBlob blob = container.getBlockBlobReference(directory + "/" + fileName);
//
//        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
//            encryptedPart.writeTo(bos);
//            blob.upload(new ByteArrayInputStream(bos.toByteArray()), bos.size());
//        } catch (Exception e) {
//            context.getLogger().severe("Error uploading encrypted message: " + e.getMessage());
//            throw e;
//        }
//    }
//
//    private InputStream downloadBlob(String fileName, String directory, ExecutionContext context) throws Exception {
//        CloudStorageAccount storageAccount = CloudStorageAccount.parse(AZURE_STORAGE_CONNECTION);
//        CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
//        CloudBlobContainer container = blobClient.getContainerReference(AZURE_CONTAINER_NAME);
//        CloudBlockBlob blob = container.getBlockBlobReference(directory + "/" + fileName);
//
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        blob.download(bos);
//        return new ByteArrayInputStream(bos.toByteArray());
//    }
//
//    private List<String> getFileNamesFromBlobDirectory(String directory, ExecutionContext context) throws Exception {
//        List<String> fileNames = new ArrayList<>();
//        CloudStorageAccount storageAccount = CloudStorageAccount.parse(AZURE_STORAGE_CONNECTION);
//        CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
//        CloudBlobContainer container = blobClient.getContainerReference(AZURE_CONTAINER_NAME);
//
//        Iterable<ListBlobItem> blobs = container.listBlobs(directory + "/");
//        for (ListBlobItem blobItem : blobs) {
//            if (blobItem instanceof CloudBlockBlob) {
//                CloudBlockBlob blob = (CloudBlockBlob) blobItem;
//                fileNames.add(blob.getName());
//                context.getLogger().info("Found blob: " + blob.getName());
//            }
//        }
//
//        return fileNames;
//    }
//}



//package com.prdTest;
//
//import com.microsoft.azure.functions.ExecutionContext;
//import com.microsoft.azure.functions.HttpMethod;
//import com.microsoft.azure.functions.HttpRequestMessage;
//import com.microsoft.azure.functions.HttpResponseMessage;
//import com.microsoft.azure.functions.HttpStatus;
//import com.microsoft.azure.functions.annotation.AuthorizationLevel;
//import com.microsoft.azure.functions.annotation.FunctionName;
//import com.microsoft.azure.functions.annotation.HttpTrigger;
//import com.microsoft.azure.storage.CloudStorageAccount;
//import com.microsoft.azure.storage.blob.CloudBlobClient;
//import com.microsoft.azure.storage.blob.CloudBlobContainer;
//import com.microsoft.azure.storage.blob.CloudBlobDirectory;
//import com.microsoft.azure.storage.blob.CloudBlockBlob;
//import com.microsoft.azure.storage.blob.ListBlobItem;
//import org.bouncycastle.asn1.smime.SMIMECapability;
//import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
//import org.bouncycastle.cert.jcajce.JcaCertStore;
//import org.bouncycastle.cms.CMSAlgorithm;
//import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoGeneratorBuilder;
//import org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder;
//import org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator;
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
//import org.bouncycastle.mail.smime.SMIMESignedGenerator;
//import org.bouncycastle.operator.OutputEncryptor;
//
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMultipart;
//import java.io.ByteArrayOutputStream;
//import java.io.FileInputStream;
//import java.io.InputStream;
//import java.security.KeyStore;
//import java.security.PrivateKey;
//import java.security.Security;
//import java.security.cert.Certificate;
//import java.security.cert.CertificateFactory;
//import java.security.cert.X509Certificate;
//import java.util.ArrayList;
//import java.util.Enumeration;
//import java.util.List;
//import java.util.Optional;
//import java.util.UUID;
//
//public class HttpTriggerFunction {
//    private static final String PROFILE_PATH = "C:\\Users\\vikash.nayak\\Downloads\\SMIMETool\\SMIMETool\\CER\\BLPFX.pfx"; // Use environment variable
//    private static final String PROFILE_PASSWORD = "Citibank#12";
//    private static final String RECIPIENT_CERT_PATH = "C:/Users/vikash.nayak/Downloads/SMIMETool2/CER/Citi.cer";
//
//    @FunctionName("HttpExample")
//    public HttpResponseMessage run(
//            @HttpTrigger(
//                    name = "req",
//                    methods = {HttpMethod.GET, HttpMethod.POST},
//                    authLevel = AuthorizationLevel.ANONYMOUS)
//                    HttpRequestMessage<Optional<String>> request,
//            final ExecutionContext context) {
//
//        context.getLogger().info("Java HTTP trigger processed a request.");
//
//
//        try {
//            String sasToken = "DefaultEndpointsProtocol=https;AccountName=azchnn3ssdevlogicapp01;AccountKey=L55niZUJ2G60rYaBV0kQaJdkia0NyqepbAaQa8EgFKHhrQSKhMJtZf0nVCGDUwscCqR3Gr+jfX+x+AStzLLkEg==;EndpointSuffix=core.chinacloudapi.cn";
//            
//            if (sasToken == null || sasToken.isBlank()) {
//                return request.createResponseBuilder(HttpStatus.BAD_REQUEST)
//                        .body("Empty SAS Token")
//                        .build();
//            }
//            
//            CloudStorageAccount storageAccount = CloudStorageAccount.parse(sasToken);
//            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
//            CloudBlobContainer blobContainer = blobClient.getContainerReference("development-citibankintegration-ap");
//            CloudBlobDirectory inBlobDirectory = blobContainer.getDirectoryReference("IN");
//            CloudBlobDirectory outBlobDirectory = blobContainer.getDirectoryReference("OUT");
//
//            for (ListBlobItem blobItem : inBlobDirectory.listBlobs()) {
//                if (blobItem instanceof CloudBlockBlob) {
//                    CloudBlockBlob blockBlob = (CloudBlockBlob) blobItem;
//
//                    try {
//                        String fileName = getFileNameFromBlobPath(blockBlob.getName());
//                        String fileExtension = getFileExtension(fileName);
//                        String baseFileName = getBaseFileName(fileName);
//
//                        String fileContent = blockBlob.downloadText();
//                        MimeBodyPart signedMessage = signMessage(fileContent, context);
//                        MimeBodyPart encryptedMessage = encryptMessage(signedMessage, baseFileName, fileExtension, outBlobDirectory, context);
//
//                        context.getLogger().info("Processed file: " + fileName);
//                    } catch (Exception e) {
//                        context.getLogger().severe("Error processing blob: " + e.getMessage());
//                    }
//                }
//            }
//            
//        } catch (Exception e) {
//            context.getLogger().severe("Error: " + e.getMessage());
//            return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Error processing request.")
//                    .build();
//        }
//
//        return request.createResponseBuilder(HttpStatus.OK)
//                .body("All files processed successfully.")
//                .build();
//    }
//
//    private MimeBodyPart signMessage(String messageContent, ExecutionContext context) throws Exception {
//        // Initialize Bouncy Castle provider
//        Security.addProvider(new BouncyCastleProvider());
//
//        // Load the keystore (containing the sender's private key and certificate)
//        KeyStore keystore = KeyStore.getInstance("PKCS12", "BC");
//        keystore.load(new FileInputStream(PROFILE_PATH), PROFILE_PASSWORD.toCharArray());
//
//        // Get the private key and certificate from the keystore
//        String keyAlias = null;
//        for (Enumeration<String> e = keystore.aliases(); e.hasMoreElements() && keyAlias == null;) {
//            String alias = e.nextElement();
//            if (keystore.isKeyEntry(alias)) {
//                keyAlias = alias;
//            }
//        }
//
//        Certificate[] chain = keystore.getCertificateChain(keyAlias);
//        PrivateKey privateKey = (PrivateKey) keystore.getKey(keyAlias, PROFILE_PASSWORD.toCharArray());
//
//        // Create the SMIMESignedGenerator for signing
//        SMIMESignedGenerator signer = new SMIMESignedGenerator();
//
//        // Set signing capabilities
//        SMIMECapabilityVector capabilities = new SMIMECapabilityVector();
//        capabilities.addCapability(SMIMECapability.dES_EDE3_CBC);
//        capabilities.addCapability(SMIMECapability.rC2_CBC, 128);
//        capabilities.addCapability(SMIMECapability.dES_CBC);
//
//        // Add the signer information
//        signer.addSignerInfoGenerator(new JcaSimpleSignerInfoGeneratorBuilder()
//                .setProvider("BC")
//                .build("SHA1withRSA", privateKey, (X509Certificate) chain[0]));
//
//        // Create certificate store and add the certificate
//        List<X509Certificate> certList = new ArrayList<>();
//        certList.add((X509Certificate) chain[0]);
//        signer.addCertificates(new JcaCertStore(certList));
//
//        // Create the message to be signed
//        MimeBodyPart messagePart = new MimeBodyPart();
//        messagePart.setText(messageContent);
//
//        // Sign the message and create a MimeMultipart
//        MimeMultipart signedMultipart = signer.generate(messagePart);
//
//        // Create a MimeBodyPart to hold the signed MimeMultipart
//        MimeBodyPart signedBodyPart = new MimeBodyPart();
//        signedBodyPart.setContent(signedMultipart);
//
//        context.getLogger().info("Message signed successfully.");
//        return signedBodyPart;
//    }
//
//    private MimeBodyPart encryptMessage(MimeBodyPart signedBodyPart, String baseFileName, String fileExtension, CloudBlobDirectory outBlobDirectory, ExecutionContext context) throws Exception {
//        // Load the recipient's public certificate (.cer file)
//        X509Certificate recipientCert = loadRecipientCertificate();
//
//        // Initialize the encrypter
//        SMIMEEnvelopedGenerator encrypter = new SMIMEEnvelopedGenerator();
//        encrypter.addRecipientInfoGenerator(new JceKeyTransRecipientInfoGenerator(recipientCert).setProvider("BC"));
//
//        // Encrypt the signed message
//        OutputEncryptor encryptor = new JceCMSContentEncryptorBuilder(CMSAlgorithm.RC2_CBC).setProvider("BC").build();
//        MimeBodyPart encryptedPart = encrypter.generate(signedBodyPart, encryptor);
//
//        // Save the encrypted message to Azure Blob Storage
//        String uniqueFileName = baseFileName + ".txt" +".p7m";
//        saveEncryptedMessageToFile(encryptedPart, uniqueFileName, outBlobDirectory, context);
//
//        context.getLogger().info("Message encrypted and uploaded successfully.");
//        return encryptedPart;
//    }
//
//    private void saveEncryptedMessageToFile(MimeBodyPart encryptedPart, String fileName, CloudBlobDirectory outBlobDirectory, ExecutionContext context) throws Exception {
//        // Upload the encrypted message to Azure Blob Storage
//        CloudBlockBlob blockBlob = outBlobDirectory.getBlockBlobReference(fileName);
//
//        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
//            // Write the encrypted MimeBodyPart to the output stream
//            encryptedPart.writeTo(baos);
//            byte[] byteArray = baos.toByteArray();
//
//            // Upload the byte array to Azure Blob Storage
//            blockBlob.uploadFromByteArray(byteArray, 0, byteArray.length);
//        }
//
//        context.getLogger().info("File uploaded to Azure Blob Storage: " + blockBlob.getUri().toString());
//    }
//
//    private X509Certificate loadRecipientCertificate() throws Exception {
//        CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
//        try (InputStream is = new FileInputStream(RECIPIENT_CERT_PATH)) {
//            return (X509Certificate) certFactory.generateCertificate(is);
//        }
//    }
//
//    private String getFileNameFromBlobPath(String blobPath) {
//        return blobPath.substring(blobPath.lastIndexOf('/') + 1);
//    }
//
//    private String getFileExtension(String fileName) {
//        int dotIndex = fileName.lastIndexOf('.');
//        return (dotIndex != -1) ? fileName.substring(dotIndex + 1) : "";
//    }
//
//    private String getBaseFileName(String fileName) {
//        int dotIndex = fileName.lastIndexOf('.');
//        return (dotIndex != -1) ? fileName.substring(0, dotIndex) : fileName;
//    }
//}

///////////////////////////////////////////////



package com.prdTest;

import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlobDirectory;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.blob.ListBlobItem;
import org.bouncycastle.asn1.smime.SMIMECapability;
import org.bouncycastle.asn1.smime.SMIMECapabilityVector;
import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.cms.CMSAlgorithm;
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoGeneratorBuilder;
import org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder;
import org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.mail.smime.SMIMEEnvelopedGenerator;
import org.bouncycastle.mail.smime.SMIMESignedGenerator;
import org.bouncycastle.operator.OutputEncryptor;

import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Optional;

public class HttpTriggerFunction {

    private static final String SAS_TOKEN = "DefaultEndpointsProtocol=https;AccountName=azchnn3ssdevlogicapp01;AccountKey=L55niZUJ2G60rYaBV0kQaJdkia0NyqepbAaQa8EgFKHhrQSKhMJtZf0nVCGDUwscCqR3Gr+jfX+x+AStzLLkEg==;EndpointSuffix=core.chinacloudapi.cn";
    private static final String CONTAINER_NAME = "development-citibankintegration-ap";
    private static final String IN_DIRECTORY = "IN";
    private static final String OUT_DIRECTORY = "OUT";
    private static final String PROFILE_BLOB_NAME = "certificate/BLPFX.pfx";
    private static final String RECIPIENT_CERT_BLOB_NAME = "certificate/Citi.cer";
    private static final String PROFILE_PASSWORD = "Citibank#12";

    @FunctionName("CitiBankEncrypt")
    public HttpResponseMessage run(
            @HttpTrigger(
                    name = "req",
                    methods = {HttpMethod.GET, HttpMethod.POST},
                    authLevel = AuthorizationLevel.ANONYMOUS)
                    HttpRequestMessage<Optional<String>> request,
            final ExecutionContext context) {

        context.getLogger().info("Java HTTP trigger processed a request.");

        try {
            CloudStorageAccount storageAccount = CloudStorageAccount.parse(SAS_TOKEN);
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
            CloudBlobContainer blobContainer = blobClient.getContainerReference(CONTAINER_NAME);
            CloudBlobDirectory inBlobDirectory = blobContainer.getDirectoryReference(IN_DIRECTORY);
            CloudBlobDirectory outBlobDirectory = blobContainer.getDirectoryReference(OUT_DIRECTORY);

            for (ListBlobItem blobItem : inBlobDirectory.listBlobs()) {
                if (blobItem instanceof CloudBlockBlob) {
                    CloudBlockBlob blockBlob = (CloudBlockBlob) blobItem;

                    try {
                        String fileName = getFileNameFromBlobPath(blockBlob.getName());
                        String fileExtension = getFileExtension(fileName);
                        String baseFileName = getBaseFileName(fileName);

                        String fileContent = blockBlob.downloadText();
                        MimeBodyPart signedMessage = signMessage(fileContent, context);
                        MimeBodyPart encryptedMessage = encryptMessage(signedMessage, baseFileName, fileExtension, outBlobDirectory, context);

                        context.getLogger().info("Processed file: " + fileName);
                    } catch (Exception e) {
                        context.getLogger().severe("Error processing blob: " + e.getMessage());
                    }
                }
            }

        } catch (Exception e) {
            context.getLogger().severe("Error: " + e.getMessage());
            return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error processing request.")
                    .build();
        }

        return request.createResponseBuilder(HttpStatus.OK)
                .body("All files processed successfully.")
                .build();
    }

    private MimeBodyPart signMessage(String messageContent, ExecutionContext context) throws Exception {
        // Initialize Bouncy Castle provider
        Security.addProvider(new BouncyCastleProvider());

        // Load the keystore (containing the sender's private key and certificate) from Azure Blob Storage
        InputStream pfxInputStream = downloadBlobAsStream(PROFILE_BLOB_NAME);
        KeyStore keystore = KeyStore.getInstance("PKCS12", "BC");
        keystore.load(pfxInputStream, PROFILE_PASSWORD.toCharArray());

        // Get the private key and certificate from the keystore
        String keyAlias = null;
        for (Enumeration<String> e = keystore.aliases(); e.hasMoreElements() && keyAlias == null;) {
            String alias = e.nextElement();
            if (keystore.isKeyEntry(alias)) {
                keyAlias = alias;
            }
        }

        Certificate[] chain = keystore.getCertificateChain(keyAlias);
        PrivateKey privateKey = (PrivateKey) keystore.getKey(keyAlias, PROFILE_PASSWORD.toCharArray());

        // Create the SMIMESignedGenerator for signing
        SMIMESignedGenerator signer = new SMIMESignedGenerator();

        // Set signing capabilities
        SMIMECapabilityVector capabilities = new SMIMECapabilityVector();
        capabilities.addCapability(SMIMECapability.dES_EDE3_CBC);
        capabilities.addCapability(SMIMECapability.rC2_CBC, 128);
        capabilities.addCapability(SMIMECapability.dES_CBC);

        // Add the signer information
        signer.addSignerInfoGenerator(new JcaSimpleSignerInfoGeneratorBuilder()
                .setProvider("BC")
                .build("SHA1withRSA", privateKey, (X509Certificate) chain[0]));

        // Create certificate store and add the certificate
        List<X509Certificate> certList = new ArrayList<>();
        certList.add((X509Certificate) chain[0]);
        signer.addCertificates(new JcaCertStore(certList));

        // Create the message to be signed
        MimeBodyPart messagePart = new MimeBodyPart();
        messagePart.setText(messageContent);

        // Sign the message and create a MimeMultipart
        MimeMultipart signedMultipart = signer.generate(messagePart);

        // Create a MimeBodyPart to hold the signed MimeMultipart
        MimeBodyPart signedBodyPart = new MimeBodyPart();
        signedBodyPart.setContent(signedMultipart);

        context.getLogger().info("Message signed successfully.");
        return signedBodyPart;
    }

    private MimeBodyPart encryptMessage(MimeBodyPart signedBodyPart, String baseFileName, String fileExtension, CloudBlobDirectory outBlobDirectory, ExecutionContext context) throws Exception {
        // Load the recipient's public certificate (.cer file) from Azure Blob Storage
        InputStream cerInputStream = downloadBlobAsStream(RECIPIENT_CERT_BLOB_NAME);
        X509Certificate recipientCert = loadCertificate(cerInputStream);

        // Initialize the encrypter
        SMIMEEnvelopedGenerator encrypter = new SMIMEEnvelopedGenerator();
        encrypter.addRecipientInfoGenerator(new JceKeyTransRecipientInfoGenerator(recipientCert).setProvider("BC"));

        // Encrypt the signed message
        OutputEncryptor encryptor = new JceCMSContentEncryptorBuilder(CMSAlgorithm.RC2_CBC).setProvider("BC").build();
        MimeBodyPart encryptedPart = encrypter.generate(signedBodyPart, encryptor);

        // Save the encrypted message to Azure Blob Storage
        String uniqueFileName = baseFileName + ".txt" + ".p7m";
        saveEncryptedMessageToFile(encryptedPart, uniqueFileName, outBlobDirectory, context);

        context.getLogger().info("Message encrypted and uploaded successfully.");
        return encryptedPart;
    }

    private InputStream downloadBlobAsStream(String blobName) throws Exception {
        CloudStorageAccount storageAccount = CloudStorageAccount.parse(SAS_TOKEN);
        CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
        CloudBlobContainer blobContainer = blobClient.getContainerReference(CONTAINER_NAME);
        CloudBlockBlob blockBlob = blobContainer.getBlockBlobReference(blobName);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        blockBlob.download(baos);
        return new ByteArrayInputStream(baos.toByteArray());
    }

    private X509Certificate loadCertificate(InputStream inputStream) throws Exception {
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        return (X509Certificate) cf.generateCertificate(inputStream);
    }

    private String getFileNameFromBlobPath(String blobPath) {
        return blobPath.substring(blobPath.lastIndexOf('/') + 1);
    }

    private String getFileExtension(String fileName) {
        return fileName.substring(fileName.lastIndexOf('.') + 1);
    }

    private String getBaseFileName(String fileName) {
        return fileName.substring(0, fileName.lastIndexOf('.'));
    }

    private void saveEncryptedMessageToFile(MimeBodyPart encryptedPart, String fileName, CloudBlobDirectory outBlobDirectory, ExecutionContext context) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        encryptedPart.writeTo(baos);

        CloudBlockBlob blob = outBlobDirectory.getBlockBlobReference(fileName);
        blob.upload(new ByteArrayInputStream(baos.toByteArray()), baos.size());

        context.getLogger().info("Encrypted message saved as: " + fileName);
    }
}

















